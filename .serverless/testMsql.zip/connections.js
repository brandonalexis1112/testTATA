const myslq = requiere('mysql');

const configDB = {
    host: 'BBDD',
    user: 'root',
    password: '1234',
    port: '3306',
    database: 'testMysql',
    debug: true
};

function initializeConnection(config) {
    function addDisconnectHandler(connection){
        connection.on("error",function(error){
            if(error instanceof Error){
                if(error.code === "PROTOCOL_CONNECTION_LOST"){
                    console.error(error.stack);
                    console.log("lost connection. reconnecting...");
                    initializeConnection(connection.config);

                } else if (error.fatal){
                    throw error;
                }
            }
        });
        
    }
    const connection = myslq.createConnection(config);
    addDisconnectHandler(connection);

    connection.connect();
    return connection;

}

const connection = initializeConnection(configDB);

module.exports = connection;