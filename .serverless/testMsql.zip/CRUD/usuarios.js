const connection = require('../connection');
const querystring = require('querystring');

module.exports.findAll = (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    const sql = 'SELECT * FROM mojodb.usuarios';
    connection.query(sql, (error, rows) => {
      if (error) {
        callback({
          statusCode: 500,
          body: JSON.stringify(error)
        })
      } else {
        callback(null, {
          statusCode: 200,
          body: JSON.stringify({
            usuarios: rows
          })
        })
      }
    })
};

module.exports.findOne = (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    const sql = 'SELECT * FROM mojodb.usuarios WHERE id = ?';
    connection.query(sql, [event.pathParameters.usuario], (error, row) => {
      if (error) {
        callback({
          statusCode: 500,
          body: JSON.stringify(error)
        })
      } else {
        callback(null, {
          statusCode: 200,
          body: JSON.stringify({
            usuario: row
          })
        })
      }
    })
  };
  module.exports.create = (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    
    const body = JSON.parse(event['body'])
    const sql = 'INSERT INTO mojodb.usuarios SET username = ?, email = ?';
    
    connection.query(sql, [body.username, body.email], (error, result) => {
      if (error) {
        callback({
          statusCode: 500,
          body: JSON.stringify(error)
        })
      } else {
        callback(null, {
          statusCode: 200,
          body: JSON.stringify({
            res: `Todo insertado correctamente con id ${result.insertId}`
          })
        })
      }
    })
  };